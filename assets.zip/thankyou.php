<?php
	include("../../includes/config.php");
	$thestory=$_GET['story'];
	$theactor=$_GET['actor'];
	$user_owner=60;
	$updating="NO";
	$description=$_GET['description'];
	$priority=$_GET['priority'];
	$biz_books=$_GET['bizbooks'];
	$describes_fin=$_GET['describesfin'];
	if(trim($thestory)=="" )
	{
		header("location:index.php?story=no");
	}else
	if(trim($theactor)=="")
	{
		header("location:index.php?actor=no");
	}
	if(trim($description)=="")
	{
		header("location:index.php?description=no");
	}
	if(trim($priority)=="")
	{
		header("location:index.php?priority=no");
	}
	//Here get the data from the user and store in Auto Responder
	$already_subscribed=mysql_query("select * from tbl_eSCMIS_Requirements where email='".$theemail."'");
	while($fetch_status=mysql_fetch_array($already_subscribed))
	{
		$updating="YES";	
		//Update the subscription
		$sqlpurchase=mysql_query("update tbl_eSCMIS_Requirements set describes_you='".$describes_you."', biz_books='".$biz_books."', describes_fin='".$describes_fin."' where email='".$theemail."'");
		//echo "We are Here";
		//exit();
				
	}
	
	if($updating=="NO")
	{
		//This is a new insert the subscriber
		 $sqlpurchase=mysql_query ("insert into tbl_eSCMIS_Requirements(user_id,name,email,Date_subscribed,describes_you,biz_books,describes_fin) values('".$user_owner."', '".$_GET['name']."', '".$_GET['email']."','".date("Y/m/d")."','".$describes_you."','".$biz_books."','".$describes_fin."')") or die ( mysql_error () );
	
		
	}
?>

<!DOCTYPE HTML>
<!--
	Theory by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>eSCMIS Requirements Tool</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<link rel="stylesheet" href="assets/css/mainthanks.css" />
	    <style type="text/css">
<!--
.style1 {font-weight: bold}
.style2 {
	color: #000000;
	font-weight: bold;
}
.style3 {color: #333333}
-->
        </style>
</head>
	<body>

		<!-- Header -->
			

		<!-- Banner -->
			<section id="banner">
				<h1>Thanks For Submitting The Requirement</h1>
                <h1>eSCMIS Requirements Gathering - April 2020</h1>
				                
			</section>
		
			<section id="two" class="wrapper">
				<div class="inner">
					<div class="flex flex-3">
                        <article>
                        </article>
						<article>
                        
                       
                        
            
             
                        
            			</article>
                        <article>
                        </article>
                        </div>
                        </div>
                       
                       
           </section>
            
            
          

		<!-- Two -->
			<section id="two" class="wrapper style1 special">
				<div class="inner">
					<header>
						<h2>Republic of Zambia</h2>
						<p>MINISTRY OF HEALTH</p>
					</header>
					<div class="flex flex-4">
						<div class="box person">
							<div class="image round">
								<img src="images/pic03.jpg" alt="Person 1" width="140" height="140" />
							</div>
							<h3>National</h3>
							
						</div>
						<div class="box person">
							<div class="image round">
								<img src="images/pic04.jpg" alt="Person 2" width="140" height="140"/>
							</div>
							<h3>Provincial</h3>
							
						</div>
						<div class="box person">
							<div class="image round">
								<img src="images/pic05.jpg" alt="Person 3" width="140" height="140" />
							</div>
							<h3>District</h3>
						
						</div>
						<div class="box person">
							<div class="image round">
								<img src="images/pic06.jpg" alt="Person 4" width="140" height="140" />
							</div>
							<h3>SDP</h3>
							
						</div>
					</div>
				</div>
			</section>

			<?php
	
				if(trim(isset($_GET["story"]))=="" )
				{
					header("location:index.php?story=no");
				
				}else
				if(trim(isset($_GET["actor"]))=="")
				{
					header("location:index.php?actor=no");
				
				}
				
			?>

		<!-- Footer -->
			

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>